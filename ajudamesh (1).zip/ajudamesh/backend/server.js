const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../frontend/dist'))); // Serve frontend in production

// SQLite setup
const db = new sqlite3.Database(':memory:'); // For demo, use file for persistence: './ajudamesh.db'

// Create tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS sos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    type TEXT,
    people INTEGER,
    location TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS shelters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    capacity INTEGER,
    occupied INTEGER,
    location TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS missing (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    lastLocation TEXT,
    photo TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user TEXT,
    text TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

// Seed some data
db.run(`INSERT OR IGNORE INTO shelters (name, capacity, occupied, location) VALUES 
  ('Escola Municipal', 150, 45, 'Centro da cidade'),
  ('Igreja São Pedro', 80, 60, 'Bairro Norte')
`);

console.log('Database initialized');

// Socket.io for real-time
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // Send initial data
  db.all("SELECT * FROM sos ORDER BY timestamp DESC", (err, rows) => {
    socket.emit('sos_list', rows || []);
  });

  db.all("SELECT * FROM shelters", (err, rows) => {
    socket.emit('shelters', rows || []);
  });

  db.all("SELECT * FROM missing", (err, rows) => {
    socket.emit('missing_list', rows || []);
  });

  db.all("SELECT * FROM messages ORDER BY timestamp DESC LIMIT 50", (err, rows) => {
    socket.emit('chat_history', rows || []);
  });

  // New SOS
  socket.on('new_sos', (data) => {
    const { name, type, people, location } = data;
    db.run(`INSERT INTO sos (name, type, people, location) VALUES (?, ?, ?, ?)`,
      [name, type, people, location], function(err) {
        if (err) return console.error(err);
        const newSos = { id: this.lastID, name, type, people, location, timestamp: new Date().toISOString() };
        io.emit('new_sos', newSos); // Broadcast to all
      });
  });

  // Chat message
  socket.on('chat_message', (data) => {
    const { user, text } = data;
    db.run(`INSERT INTO messages (user, text) VALUES (?, ?)`, [user, text], function(err) {
      if (err) return;
      const msg = { id: this.lastID, user, text, timestamp: new Date().toISOString() };
      io.emit('new_message', msg);
    });
  });

  // Update shelter
  socket.on('update_shelter', (data) => {
    const { id, occupied } = data;
    db.run(`UPDATE shelters SET occupied = ? WHERE id = ?`, [occupied, id], (err) => {
      if (err) return;
      db.all("SELECT * FROM shelters", (err, rows) => {
        io.emit('shelters', rows);
      });
    });
  });

  // New missing person
  socket.on('new_missing', (data) => {
    const { name, lastLocation, photo } = data;
    db.run(`INSERT INTO missing (name, lastLocation, photo) VALUES (?, ?, ?)`,
      [name, lastLocation, photo || null], function(err) {
        if (err) return;
        const newMissing = { id: this.lastID, name, lastLocation, photo, timestamp: new Date().toISOString() };
        io.emit('new_missing', newMissing);
      });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// REST endpoints for offline sync simulation
app.get('/api/sos', (req, res) => {
  db.all("SELECT * FROM sos ORDER BY timestamp DESC", (err, rows) => {
    res.json(rows);
  });
});

app.post('/api/sos', (req, res) => {
  const { name, type, people, location } = req.body;
  db.run(`INSERT INTO sos (name, type, people, location) VALUES (?, ?, ?, ?)`,
    [name, type, people, location], function(err) {
      if (err) return res.status(500).json({error: err});
      res.json({ id: this.lastID, success: true });
    });
});

app.get('/api/shelters', (req, res) => {
  db.all("SELECT * FROM shelters", (err, rows) => {
    res.json(rows);
  });
});

app.get('/api/missing', (req, res) => {
  db.all("SELECT * FROM missing", (err, rows) => {
    res.json(rows);
  });
});

app.get('/api/messages', (req, res) => {
  db.all("SELECT * FROM messages ORDER BY timestamp DESC LIMIT 100", (err, rows) => {
    res.json(rows);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚨 AjudaMesh Server running on http://0.0.0.0:${PORT}`);
  console.log('📡 Connect devices to local WiFi and access http://192.168.4.1:3000 or similar');
});
