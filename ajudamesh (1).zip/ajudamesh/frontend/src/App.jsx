import { useState, useEffect } from 'react';
import io from 'socket.io-client';
import './App.css';

const socket = io('http://localhost:3000', { autoConnect: true });

function App() {
  const [activeTab, setActiveTab] = useState('sos');
  const [userName, setUserName] = useState('Usuário' + Math.floor(Math.random() * 100));
  const [sosList, setSosList] = useState([]);
  const [shelters, setShelters] = useState([]);
  const [missingList, setMissingList] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [newSos, setNewSos] = useState({ name: '', type: 'resgate', people: 1, location: '' });
  const [newMissing, setNewMissing] = useState({ name: '', lastLocation: '' });
  const [isConnected, setIsConnected] = useState(false);
  const [notification, setNotification] = useState('');

  useEffect(() => {
    socket.on('connect', () => {
      setIsConnected(true);
      console.log('Connected to AjudaMesh server');
    });

    socket.on('disconnect', () => {
      setIsConnected(false);
    });

    socket.on('sos_list', (data) => setSosList(data));
    socket.on('new_sos', (sos) => {
      setSosList(prev => [sos, ...prev]);
      showNotification(`Novo SOS de ${sos.name}!`);
    });

    socket.on('shelters', (data) => setShelters(data));
    socket.on('missing_list', (data) => setMissingList(data));
    socket.on('new_missing', (m) => {
      setMissingList(prev => [m, ...prev]);
    });

    socket.on('chat_history', (data) => setChatMessages(data));
    socket.on('new_message', (msg) => {
      setChatMessages(prev => [msg, ...prev].slice(0, 50));
    });

    return () => {
      socket.off();
    };
  }, []);

  const showNotification = (msg) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 4000);
  };

  const sendSos = () => {
    if (!newSos.name) return alert('Nome é obrigatório');
    socket.emit('new_sos', newSos);
    setNewSos({ name: userName, type: 'resgate', people: 1, location: '' });
    showNotification('SOS enviado!');
  };

  const sendChatMessage = () => {
    if (!newMessage.trim()) return;
    socket.emit('chat_message', { user: userName, text: newMessage });
    setNewMessage('');
  };

  const reportMissing = () => {
    if (!newMissing.name) return;
    socket.emit('new_missing', newMissing);
    setNewMissing({ name: '', lastLocation: '' });
    showNotification('Pessoa desaparecida reportada!');
  };

  const updateShelter = (id, newOccupied) => {
    socket.emit('update_shelter', { id, occupied: parseInt(newOccupied) });
  };

  // For offline simulation - IndexedDB would be used here in full PWA
  // For MVP, rely on local state + server sync

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans">
      {/* Header */}
      <header className="bg-red-950 border-b border-red-900 p-4 flex justify-between items-center sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-xl font-bold">🆘</div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">AJUDAMESH</h1>
            <p className="text-xs text-red-400">Rede Local de Emergência</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className={`px-3 py-1 rounded-full flex items-center gap-1 ${isConnected ? 'bg-green-600' : 'bg-red-600'}`}>
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-300 animate-pulse' : 'bg-red-300'}`}></div>
            {isConnected ? 'Conectado Local' : 'Offline'}
          </div>
          <div className="text-gray-400">Olá, {userName}</div>
        </div>
      </header>

      {/* Notification */}
      {notification && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 bg-red-600 text-white px-6 py-3 rounded-xl shadow-2xl z-50 flex items-center gap-2">
          ⚠️ {notification}
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-gray-800 bg-gray-900 sticky top-16 z-40 overflow-x-auto">
        {['sos', 'chat', 'shelters', 'missing'].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-4 font-medium whitespace-nowrap flex-1 ${activeTab === tab 
              ? 'border-b-2 border-red-500 text-white' 
              : 'text-gray-400 hover:text-gray-200'}`}
          >
            {tab === 'sos' && '🚨 SOS'}
            {tab === 'chat' && '💬 Chat'}
            {tab === 'shelters' && '🏠 Abrigos'}
            {tab === 'missing' && '👤 Desaparecidos'}
          </button>
        ))}
      </div>

      <div className="max-w-4xl mx-auto p-4 pb-24">
        {/* SOS Tab */}
        {activeTab === 'sos' && (
          <div className="space-y-6">
            <div className="bg-gray-900 rounded-2xl p-6 border border-red-900">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">🚨 Enviar Pedido de Socorro</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Seu Nome"
                  value={newSos.name}
                  onChange={(e) => setNewSos({...newSos, name: e.target.value})}
                  className="bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
                />
                <select 
                  value={newSos.type}
                  onChange={(e) => setNewSos({...newSos, type: e.target.value})}
                  className="bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500"
                >
                  <option value="resgate">Resgate</option>
                  <option value="agua">Água</option>
                  <option value="comida">Comida</option>
                  <option value="medicamentos">Medicamentos</option>
                  <option value="outro">Outro</option>
                </select>
                <input
                  type="number"
                  placeholder="Número de Pessoas"
                  value={newSos.people}
                  onChange={(e) => setNewSos({...newSos, people: parseInt(e.target.value)})}
                  className="bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500"
                />
                <input
                  type="text"
                  placeholder="Localização (ex: Rua Principal, 45)"
                  value={newSos.location}
                  onChange={(e) => setNewSos({...newSos, location: e.target.value})}
                  className="bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
                />
              </div>
              <button 
                onClick={sendSos}
                className="mt-6 w-full bg-red-600 hover:bg-red-700 py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                ENVIAR SOS IMEDIATO
              </button>
              <p className="text-center text-xs text-gray-500 mt-3">Este pedido será transmitido para todos na rede local</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">Pedidos Ativos</h3>
              {sosList.length === 0 ? (
                <div className="bg-gray-900 p-8 rounded-2xl text-center text-gray-400">Nenhum SOS ativo no momento.</div>
              ) : (
                <div className="space-y-4">
                  {sosList.map((sos, index) => (
                    <div key={index} className="bg-gray-900 border border-red-900/50 rounded-2xl p-5">
                      <div className="flex justify-between">
                        <div>
                          <div className="font-semibold text-red-400">{sos.name}</div>
                          <div className="text-2xl font-bold mt-1">{sos.type.toUpperCase()}</div>
                        </div>
                        <div className="text-right text-sm text-gray-400">
                          {new Date(sos.timestamp).toLocaleTimeString('pt-BR')}
                        </div>
                      </div>
                      <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                        <div><span className="text-gray-500">Pessoas:</span> {sos.people}</div>
                        <div><span className="text-gray-500">Local:</span> {sos.location || 'Não informado'}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Chat Tab */}
        {activeTab === 'chat' && (
          <div className="bg-gray-900 rounded-3xl overflow-hidden h-[calc(100vh-220px)] flex flex-col">
            <div className="p-4 border-b border-gray-800 bg-gray-950 flex items-center gap-3">
              <div>💬</div>
              <div>
                <div className="font-semibold">Chat Comunitário</div>
                <div className="text-xs text-emerald-400">Em tempo real • Todos na rede</div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-950" id="chat-container">
              {chatMessages.length === 0 ? (
                <div className="text-center py-12 text-gray-500">Nenhuma mensagem ainda. Seja o primeiro a falar!</div>
              ) : (
                chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.user === userName ? 'justify-end' : ''}`}>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${msg.user === userName ? 'bg-red-600 text-white' : 'bg-gray-800'}`}>
                      <div className="text-xs opacity-70 mb-1">{msg.user}</div>
                      <div>{msg.text}</div>
                      <div className="text-[10px] opacity-50 mt-1 text-right">{new Date(msg.timestamp).toLocaleTimeString()}</div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-4 border-t border-gray-800 bg-gray-900 flex gap-2">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
                placeholder="Digite uma mensagem para a comunidade..."
                className="flex-1 bg-gray-800 border border-gray-700 rounded-2xl px-5 py-4 focus:outline-none focus:border-red-500"
              />
              <button 
                onClick={sendChatMessage}
                className="bg-red-600 hover:bg-red-700 px-8 rounded-2xl font-medium"
              >
                Enviar
              </button>
            </div>
          </div>
        )}

        {/* Shelters Tab */}
        {activeTab === 'shelters' && (
          <div>
            <h3 className="text-lg font-semibold mb-4">Abrigos Disponíveis</h3>
            <div className="space-y-4">
              {shelters.map((shelter) => (
                <div key={shelter.id} className="bg-gray-900 rounded-2xl p-6 border border-gray-700">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-xl font-bold">{shelter.name}</h4>
                      <p className="text-gray-400">{shelter.location}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-mono font-bold text-emerald-400">{shelter.occupied}/{shelter.capacity}</div>
                      <div className="text-xs text-gray-500">ocupados</div>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <label className="text-sm text-gray-400 block mb-2">Atualizar Ocupação</label>
                    <div className="flex gap-3">
                      <input 
                        type="number" 
                        defaultValue={shelter.occupied}
                        onBlur={(e) => updateShelter(shelter.id, e.target.value)}
                        className="bg-gray-800 w-24 px-4 py-2 rounded-xl border border-gray-700 focus:border-red-500"
                      />
                      <button 
                        onClick={() => updateShelter(shelter.id, shelter.occupied + 5)}
                        className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-xl text-sm"
                      >
                        +5
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              {shelters.length === 0 && <div className="p-12 text-center bg-gray-900 rounded-2xl">Nenhum abrigo cadastrado.</div>}
            </div>
          </div>
        )}

        {/* Missing Tab */}
        {activeTab === 'missing' && (
          <div className="space-y-6">
            <div className="bg-gray-900 rounded-2xl p-6">
              <h3 className="font-semibold text-lg mb-4">Reportar Desaparecido</h3>
              <input 
                type="text" 
                placeholder="Nome da pessoa" 
                value={newMissing.name}
                onChange={(e) => setNewMissing({...newMissing, name: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 mb-4"
              />
              <input 
                type="text" 
                placeholder="Última localização conhecida" 
                value={newMissing.lastLocation}
                onChange={(e) => setNewMissing({...newMissing, lastLocation: e.target.value})}
                className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 mb-6"
              />
              <button 
                onClick={reportMissing}
                className="w-full py-4 bg-amber-600 hover:bg-amber-700 rounded-2xl font-semibold"
              >
                REPORTAR DESAPARECIDO
              </button>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Pessoas Desaparecidas</h3>
              {missingList.length > 0 ? (
                missingList.map((person, i) => (
                  <div key={i} className="bg-gray-900 rounded-2xl p-5 mb-4 flex gap-4">
                    <div className="w-12 h-12 bg-gray-700 rounded-xl flex-shrink-0 flex items-center justify-center text-2xl">👤</div>
                    <div className="flex-1">
                      <div className="font-semibold text-lg">{person.name}</div>
                      <div className="text-gray-400">Visto pela última vez em: {person.lastLocation}</div>
                      <div className="text-xs text-gray-500 mt-2">{new Date(person.timestamp).toLocaleString('pt-BR')}</div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="bg-gray-900 p-12 rounded-2xl text-center">Nenhuma pessoa reportada como desaparecida.</div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Nav Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 md:hidden">
        <div className="flex text-xs">
          {['sos', 'chat', 'shelters', 'missing'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-4 flex flex-col items-center ${activeTab === tab ? 'text-red-500' : 'text-gray-400'}`}
            >
              {tab === 'sos' && <span className="text-2xl mb-0.5">🚨</span>}
              {tab === 'chat' && <span className="text-2xl mb-0.5">💬</span>}
              {tab === 'shelters' && <span className="text-2xl mb-0.5">🏠</span>}
              {tab === 'missing' && <span className="text-2xl mb-0.5">👤</span>}
              <span className="uppercase tracking-widest text-[10px]">{tab}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;
